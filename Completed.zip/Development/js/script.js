$(document).ready(function() {

    $('.olf-list').click(function() {
        var index = $(this).index();

        if (!$(this).children().hasClass('olf-active')) {
            $('.olf-list a').removeClass('olf-active');
            $(this).children().addClass('olf-active')
            $('.olf-page').removeClass('olf-page-active');
            $('.olf-page').eq(index).addClass('olf-page-active');
        }

        if(index !== 0) {
            $('.olf-banner-image').addClass('olf-resize-banner');
        } else {
            $('.olf-banner-image').removeClass('olf-resize-banner');
        }

        if ($('.olf-menu-pages').hasClass('olf-menu-active')) {
            $('.olf-menu-pages').removeClass('olf-menu-active');  
        }

    });
    
    $('.olf-menu').click(function(){
        if ($('.olf-menu-pages').hasClass('olf-menu-active')) {
            $('.olf-menu-pages').removeClass('olf-menu-active');  
        } else {
            $('.olf-menu-pages').addClass('olf-menu-active');
        }
     });

     $('.olf-menu-pages').click(function() {
        if ($('.olf-menu-pages').hasClass('olf-menu-active')) {
            $('.olf-menu-pages').removeClass('olf-menu-active');  
        } 
     });
     $( function() {
    $( "#datepicker" ).datepicker();
  } );

});