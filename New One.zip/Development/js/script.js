$(document).ready(function() {


    // ****************************Page Navigations***********************************
    var registrationPage = function () {
        currentPage = 0;
            $('.olf-container').addClass('olf-registration');
            $('.olf-register-page').removeClass('olf-register-active');
            $('.olf-register-page').eq(0).addClass('olf-register-active');
            $('.olf-register-controls').css('display', 'block');
            $('.olf-register-controls').removeClass('olf-diet-controls');
            $('.olf-register-controls').removeClass('olf-travel-controls');
            $('.olf-container').removeClass('olf-travel');
            $('.olf-register-controls button:first-child').removeClass('olf-prev');
            $('.olf-banner-image').removeClass('olf-resize-banner');
    }

    $('.olf-list').click(function() {
        var index = $(this).index();

        if (!$(this).children().hasClass('olf-active')) {
            $('.olf-list a').removeClass('olf-active');
            $(this).children().addClass('olf-active')
            $('.olf-page').removeClass('olf-page-active');
            $('.olf-page').eq(index).addClass('olf-page-active');
        }

        if (index !== 0) {
            $('.olf-banner-image').addClass('olf-resize-banner');
        } else {
            $('.olf-banner-image').removeClass('olf-resize-banner');
        }

        if ($('.olf-menu-pages').hasClass('olf-menu-active')) {
            $('.olf-menu-pages').removeClass('olf-menu-active');
        }

        if (index === 3) {
            registrationPage();
        }

    });

    
    $('.olf-registration-link button').click(function() {
        $('.olf-page').removeClass('olf-page-active');
        $('.olf-page').eq(3).addClass('olf-page-active');
        registrationPage();
    })

    $('.olf-menu').click(function() {
        if ($('.olf-menu-pages').hasClass('olf-menu-active')) {
            $('.olf-menu-pages').removeClass('olf-menu-active');
        } else {
            $('.olf-menu-pages').addClass('olf-menu-active');
        }
    });

    $('.olf-menu-pages').click(function() {
        if ($('.olf-menu-pages').hasClass('olf-menu-active')) {
            $('.olf-menu-pages').removeClass('olf-menu-active');
        }
    });

    $('.olf-home').click(function() {
        $('.olf-container').removeClass('olf-registration');
        $('.olf-list a').removeClass('olf-active');
        $('.olf-list').eq(0).children().addClass('olf-active');
        $('.olf-page').removeClass('olf-page-active');
        $('.olf-page').eq(0).addClass('olf-page-active');
    });


    // ****************************Regsitration Page*****************************
    var $page = $('.olf-register-page');
    var totalPage = ($page.length - 1)
    var currentPage = 0;
    $('.olf-next').click(function() {
        $(window).scrollTop(0);
        if (currentPage === totalPage) {
            return false;
        } else {
            currentPage = currentPage + 1;
        }
        navigatePage(currentPage);
    });

    $('.olf-register-controls button:first-child').click(function() {
        $(window).scrollTop(0);
        if (currentPage === 0) {
            return false;
        } else {
            currentPage = currentPage - 1;
        }
        navigatePage(currentPage);
    })

    var navigatePage = function(index) {
        console.log(index);
        $('.olf-register-page').removeClass('olf-register-active');
        $('.olf-register-page').eq(index).addClass('olf-register-active');
        if (index >= 1) {
            $('.olf-register-controls button:first-child').addClass('olf-prev');
        } else {
            $('.olf-register-controls button:first-child').removeClass('olf-prev');
        }
        if (index === 4) {
            $('.olf-register-controls').css('display', 'none');
        } else {
            $('.olf-register-controls').css('display', 'block');
        }
        if (index === 2) {
            $('.olf-register-controls').removeClass('olf-travel-controls');
            $('.olf-container').removeClass('olf-travel');
            $('.olf-register-controls').addClass('olf-diet-controls');
        } else if (index === 3 || index === 4) {
            if ($('.olf-register-controls').hasClass('olf-diet-controls')) {
                $('.olf-register-controls').removeClass('olf-diet-controls');
            }
            $('.olf-container').addClass('olf-travel');
            $('.olf-register-controls').addClass('olf-travel-controls');
        } else {
            $('.olf-register-controls').removeClass('olf-diet-controls');
            $('.olf-register-controls').removeClass('olf-travel-controls');
            $('.olf-container').removeClass('olf-travel');
        }
        if( index === 3 ) {
            $('.olf-breadcrumb-pages li').removeClass('olf-breadcrumb-active');
            $('.olf-breadcrumb-pages li').eq(1).addClass('olf-breadcrumb-active');
        } else if( index === 4 ) {
            $('.olf-breadcrumb-pages li').removeClass('olf-breadcrumb-active');
            $('.olf-breadcrumb-pages li').eq(2).addClass('olf-breadcrumb-active');          
        }
    }

    // ***************************Print Function***************************
    $(".olf-print").click(function () {
        $('.olf-breadcrumb').css('display','none');
        window.print();
        $('.olf-breadcrumb').css('display','block');
    });



        $(".olf-datepicker").datepicker({
            buttonImage: 'images/date-picker-icon.png',
            buttonImageOnly: true,
            changeMonth: false,
            changeYear: false,
            showOn: 'both',
            onSelect: function(dateText, inst) {
                     var pieces = dateText.split('/');
                        $(this).siblings('input').eq(0).val(pieces[0]);
                        $(this).siblings('input').eq(1).val(pieces[1]);
                       $(this).siblings('input').eq(2).val(pieces[2]);
                   }
        });

            $( ".olf-datepicker" ).datepicker().on('focus', function(e) {
                alert();
            $( ".olf-datepicker" ).datepicker('widget').css('top','625px');
            });
    
});