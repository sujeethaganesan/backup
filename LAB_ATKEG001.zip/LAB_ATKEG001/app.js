$(document).ready(function() {
  $('#insurance').load('views/insurance.html');

  $('body').on('click','#optionsRadio',function(){
    $(this).closest('.landing-page').find('form').slideDown();
  });
  /*GET JSON response combined for multiple URL*/
  $.when(
    $.getJSON('response-json/brand.json'),
    $.getJSON('response-json/model.json'),
    $.getJSON('response-json/type.json')
  ).then(function(getBrandList, getBrandModel, getBrandType) {
    var brandOptions= '', modelOptions= '', typeOptions = '';
    $.each(getBrandList[0].carsBrand[0], function(key, value) {
      brandOptions += '<option value=' + key + '>' + value + '</option>';
      $('.brand').html(brandOptions);
    });
    $.each(getBrandModel[0], function(key, value) {
      modelOptions += '<option value=' + key + '>' + value + '</option>';
      $('.model').html(modelOptions);
    });
    $.each(getBrandType[0].carsType[0], function(key, value) {
      typeOptions += '<option value=' + key + '>' + value + '</option>';
      $('.type').html(typeOptions);
    });
  }).fail(function() {
    alert('unable to load JSON, reload and try again');
  });


  /*GET ajax JSON method for each URL*/
  /*$.ajax({
    type: 'GET',
    url: 'response-json/brand.json',
    contentType: "application/json",
    dataType: 'json'
  }).done(function(getBrandList) {
    var brandOptions = "";
    $.each(getBrandList.carsBrand, function() {
      $.each(this, function(key, value) {
        brandOptions += '<option value=' + key + '>' + value + '</option>';
        $('.brand').html(brandOptions);
      });
    });
  });
  $.ajax({
    type: 'GET',
    url: 'response-json/model.json',
    contentType: "application/json",
    dataType: 'json'
  }).done(function(getBrandList) {
    var brandOptions = "";
    $.each(getBrandList, function(key, value) {
      brandOptions += '<option value=' + key + '>' + value + '</option>';
      $('.model').html(brandOptions);
    });
  });
  $.ajax({
    type: 'GET',
    url: 'response-json/type.json',
    contentType: "application/json",
    dataType: 'json'
  }).done(function(getBrandList) {
    var brandOptions = "";
    $.each(getBrandList.carsType, function() {
      $.each(this, function(key, value) {
        brandOptions += '<option value=' + key + '>' + value + '</option>';
        $('.type').html(brandOptions);
      });
    });
    
  });*/

  $('body').on('click','.form-submit', function() {
    var validFields = $('form .form-control');
    $(validFields).each(function() {
      if( $(this).val()== '' ) {
        $(this).parent().addClass('has-error');
      }
      else {
        $(this).parent().removeClass('has-error');
      }
    });
    var fieldArr = [];
    $.each( validFields, function(i) {
     fieldArr[i] = $(this).val();
      if (i === (validFields.length-1)) {
        var getArrElem = fieldArr.filter(Boolean);
        if (getArrElem.length === i+1) {
          //$(this).parent().addClass('has-error');
          console.log('success');
          $(this).closest('.landing-page').hide();
          $('.select-items').show();
        }
      }
    });
  });
  $.when(
    $.getJSON('response-json/dragItems.json')
  ).done(function(getDragList) {
    $.each(getDragList.dragItemList[0], function(key, value) {
      $('.drag-items').append('<li draggable="true" id='+key + '>' + key + ' - ' +  value + '</li>');
    });
  });

/* Drag & Drop */
  $('body').on('dragstart','.drag-items li',function(e) {
    e.originalEvent.dataTransfer.setData("text", e.target.id);
  });

  $('body').on('drop','#drop',function(e) {
    e.preventDefault();
    var data = e.originalEvent.dataTransfer.getData("text");
    e.target.appendChild(document.getElementById(data));
  });

  $('body').on('dragover','#drop',function(e) {
    e.preventDefault();
  });

  $('body').on('click','.list-submit', function() {
    $(this).closest('.select-items').hide();
    $('.preview-page').show();
    $.ajax({
      type: 'POST',
      url: 'response-json/postValue.json',
      contentType: "application/json",
      dataType: 'json'
    }).done(function(postList) {
      var brandOptions = "";
      $.each(postList.postItemList, function() {
        $.each(this, function(key, value) {
          brandOptions += '<option value=' + key + '>' + value + '</option>';
          $('.brand').html(brandOptions);
        });
      });
    });
  });
});