$(document).ready(function() {

    $('.olf-list').click(function() {
        var index = $(this).index();

        if (!$(this).children().hasClass('olf-active')) {
            $('.olf-list a').removeClass('olf-active');
            $(this).children().addClass('olf-active')
            $('.olf-page').removeClass('olf-page-active');
            $('.olf-page').eq(index).addClass('olf-page-active');
        }

        if (index !== 0) {
            $('.olf-banner-image').addClass('olf-resize-banner');
        } else {
            $('.olf-banner-image').removeClass('olf-resize-banner');
        }

        if ($('.olf-menu-pages').hasClass('olf-menu-active')) {
            $('.olf-menu-pages').removeClass('olf-menu-active');
        }

        if (index === 3) {
            currentPage = 0;
            $('.olf-container').addClass('olf-registration');
            $('.olf-register-page').removeClass('olf-register-active');
            $('.olf-register-page').eq(0).addClass('olf-register-active');
            $('.olf-register-controls').css('display', 'block');
            $('.olf-register-controls').removeClass('olf-diet-controls');
            $('.olf-register-controls').removeClass('olf-travel-controls');
            $('.olf-container').removeClass('olf-travel');
            $('.olf-register-controls button:first-child').removeClass('olf-prev');
            $('.olf-banner-image').removeClass('olf-resize-banner');
        }

    });

    $('.olf-menu').click(function() {
        if ($('.olf-menu-pages').hasClass('olf-menu-active')) {
            $('.olf-menu-pages').removeClass('olf-menu-active');
        } else {
            $('.olf-menu-pages').addClass('olf-menu-active');
        }
    });

    $('.olf-menu-pages').click(function() {
        if ($('.olf-menu-pages').hasClass('olf-menu-active')) {
            $('.olf-menu-pages').removeClass('olf-menu-active');
        }
    });

    $('.olf-breadcrumb-icon').click(function() {
        if ($('.olf-breadcrumb-pages').hasClass('olf-registration-active')) {
            $('.olf-breadcrumb-pages').removeClass('olf-registration-active');
        } else {
            $('.olf-breadcrumb-pages').addClass('olf-registration-active');
        }
    });

    $('.olf-breadcrumb-pages').click(function() {
        if ($('.olf-breadcrumb-pages').hasClass('olf-registration-active')) {
            $('.olf-breadcrumb-pages').removeClass('olf-registration-active');
        }
    });

    $('.olf-home').click(function() {
        $('.olf-container').removeClass('olf-registration');
        $('.olf-list a').removeClass('olf-active');
        $('.olf-list').eq(0).children().addClass('olf-active');
        $('.olf-page').removeClass('olf-page-active');
        $('.olf-page').eq(0).addClass('olf-page-active');
    });

    var $page = $('.olf-register-page');
    var totalPage = ($page.length - 1)
    var currentPage = 0;
    $('.olf-next').click(function() {
        if (currentPage === totalPage) {
            return false;
        } else {
            currentPage = currentPage + 1;
        }
        navigatePage(currentPage);
    });

    $('.olf-register-controls button:first-child').click(function() {
        if (currentPage === 0) {
            return false;
        } else {
            currentPage = currentPage - 1;
        }
        navigatePage(currentPage);
    })

    var navigatePage = function(index) {
        $('.olf-register-page').removeClass('olf-register-active');
        $('.olf-register-page').eq(index).addClass('olf-register-active');
        if (index >= 1) {
            $('.olf-register-controls button:first-child').addClass('olf-prev');
        } else {
            $('.olf-register-controls button:first-child').removeClass('olf-prev');
        }
        if (index === 4) {
            $('.olf-register-controls').css('display', 'none');
        } else {
            $('.olf-register-controls').css('display', 'block');
        }
        if (index === 2) {
            $('.olf-register-controls').removeClass('olf-travel-controls');
            $('.olf-container').removeClass('olf-travel');
            $('.olf-register-controls').addClass('olf-diet-controls');
        } else if (index === 3 || index === 4) {
            if ($('.olf-register-controls').hasClass('olf-diet-controls')) {
                $('.olf-register-controls').removeClass('olf-diet-controls');
            }
            $('.olf-container').addClass('olf-travel');
            $('.olf-register-controls').addClass('olf-travel-controls');
        } else {
            $('.olf-register-controls').removeClass('olf-diet-controls');
            $('.olf-register-controls').removeClass('olf-travel-controls');
            $('.olf-container').removeClass('olf-travel');
        }
    }
});